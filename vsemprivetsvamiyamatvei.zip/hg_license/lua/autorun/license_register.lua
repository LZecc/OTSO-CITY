if CLIENT then
    concommand.Add("set_license_text", function(ply, cmd, args)
        local tr = ply:GetEyeTrace()
        if not IsValid(tr.Entity) or tr.Entity:GetClass() ~= "ent_license" then return end

        local mayor = args[1] or "Неизвестный"
        local perm = table.concat(args, " ", 2) or "Без разрешения"

        net.Start("license_set_text")
        net.WriteEntity(tr.Entity)
        net.WriteString(mayor)
        net.WriteString(perm)
        net.SendToServer()
    end)
end
