include("shared.lua")

function ENT:Draw()
    self:DrawModel()

    local pos = self:GetPos()
    local ang = self:GetAngles()

    local textAng = ang
    textAng:RotateAroundAxis(textAng:Right(), 0)
    textAng:RotateAroundAxis(textAng:Up(), 90)

    cam.Start3D2D(pos + ang:Up() * 1.5, textAng, 0.1)
        draw.SimpleText("Лицензия", "DermaLarge", 0, -40, Color(255,255,255), TEXT_ALIGN_CENTER)
        draw.SimpleText("Подписано мэром: " .. self:GetMayorName(), "DermaDefault", 0, 0, Color(200,200,200), TEXT_ALIGN_CENTER)
        draw.SimpleText(self:GetPermissionText(), "DermaDefault", 0, 20, Color(200,200,200), TEXT_ALIGN_CENTER)
    cam.End3D2D()
end

net.Receive("license_open_menu", function()
    local ent = net.ReadEntity()
    if not IsValid(ent) then return end

    local frame = vgui.Create("DFrame")
    frame:SetSize(300, 200)
    frame:Center()
    frame:SetTitle("Редактирование лицензии")
    frame:MakePopup()

    local mayorEntry = vgui.Create("DTextEntry", frame)
    mayorEntry:SetPos(25, 50)
    mayorEntry:SetSize(250, 25)
    mayorEntry:SetValue(ent:GetMayorName())

    local permEntry = vgui.Create("DTextEntry", frame)
    permEntry:SetPos(25, 90)
    permEntry:SetSize(250, 25)
    permEntry:SetValue(ent:GetPermissionText())

    local saveButton = vgui.Create("DButton", frame)
    saveButton:SetPos(25, 130)
    saveButton:SetSize(250, 30)
    saveButton:SetText("Сохранить изменения")

    saveButton.DoClick = function()
        net.Start("license_set_text")
        net.WriteEntity(ent)
        net.WriteString(mayorEntry:GetValue())
        net.WriteString(permEntry:GetValue())
        net.SendToServer()
        frame:Close()
    end
end)
