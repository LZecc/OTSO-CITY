AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

util.AddNetworkString("license_open_menu")
util.AddNetworkString("license_set_text")

function ENT:Initialize()
    self:SetModel("models/props_lab/clipboard.mdl")
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)

    local phys = self:GetPhysicsObject()
    if phys:IsValid() then phys:Wake() end

    self:SetMayorName("Мэр не указан")
    self:SetPermissionText("Разрешает: ничего")
end

function ENT:Use(activator)
    if not IsValid(activator) or not activator:IsPlayer() then return end

    if activator == self:GetOwnerPlayer() then
        net.Start("license_open_menu")
        net.WriteEntity(self)
        net.Send(activator)
    else
        activator:ChatPrint("Вы не владелец этой лицензии")
    end
end

function ENT:SpawnFunction(ply, tr, ClassName)
    if not tr.Hit then return end
    local spawnPos = tr.HitPos + tr.HitNormal * 10

    local ent = ents.Create(ClassName)
    ent:SetPos(spawnPos)
    ent:Spawn()
    ent:Activate()
    ent:SetOwnerPlayer(ply)
    ply:ChatPrint("Нажмите E чтобы отредактировать лицензию.")
    return ent
end

net.Receive("license_set_text", function(len, ply)
    local ent = net.ReadEntity()
    local mayor = net.ReadString()
    local perm = net.ReadString()

    if IsValid(ent) and ent:GetClass() == "ent_license" and ent:GetOwnerPlayer() == ply then
        ent:SetMayorName(mayor)
        ent:SetPermissionText(perm)
    else
        ply:ChatPrint("Вы не можете редактировать эту лицензию!")
    end
end)
