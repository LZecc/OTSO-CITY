ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Лицензия"
ENT.Author = "LZec"
ENT.Spawnable = true
ENT.Category = "ZCity Other"

function ENT:SetupDataTables()
    self:NetworkVar("Entity", 0, "OwnerPlayer") 
    self:NetworkVar("String", 1, "MayorName")
    self:NetworkVar("String", 2, "PermissionText")
end