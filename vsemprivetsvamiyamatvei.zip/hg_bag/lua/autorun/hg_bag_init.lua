if SERVER then
    AddCSLuaFile()
end

include("hg_bag/sh_config.lua")

if SERVER then
    include("hg_bag/sv_inventory.lua")
end

if CLIENT then
    include("hg_bag/cl_ui.lua")
end
