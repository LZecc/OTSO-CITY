local colBg = Color(20,20,20,220)
local fr = vgui.Create("ZFrame")
HG_BAG_UI = fr
fr:SetSize(ScrW()/3, ScrH()/2.5)
fr:Center()
fr:SetTitle("")
fr:MakePopup()


fr.PaintOver = function(self,w,h)
draw.DrawText("Bag", "HomigradFontSmall", w/2, 10, color_white, TEXT_ALIGN_CENTER)
draw.DrawText("E - положить | ЛКМ - взять", "HomigradFontSmall", w/2, h-25, Color(255,255,255,40), TEXT_ALIGN_CENTER)
end


local scroll = vgui.Create("DScrollPanel", fr)
scroll:Dock(FILL)
scroll:DockMargin(12,32,12,32)


local grid = vgui.Create("DGrid", scroll)
grid:Dock(FILL)
grid:SetCols(5)
grid:SetColWide(fr:GetWide()/5 - 12)
grid:SetRowHeight(fr:GetWide()/5 - 12)


for i = 1, hg_bag.Slots do
local class = inv[i]
local wep = class and weapons.Get(class)


local btn = vgui.Create("DButton")
btn:SetText("")
btn:SetSize(100,100)


btn.Paint = function(self,w,h)
draw.RoundedBox(0,0,0,w,h,colBg)
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,colHover)
end


if wep and wep.WepSelectIcon then
surface.SetDrawColor(255,255,255)
surface.SetTexture(wep.WepSelectIcon)
surface.DrawTexturedRect(4,4,w-8,h-8)
end
end


if class then
btn.DoClick = function()
net.Start("hg_bag_take")
net.WriteEntity(bag)
net.WriteUInt(i, 8)
net.SendToServer()
fr:Close()
end
end


grid:AddItem(btn)
end
end


net.Receive("hg_bag_open", function()
local bag = net.ReadEntity()
local inv = net.ReadTable()
hg_bag.OpenUI(bag, inv)
end)