util.AddNetworkString("hg_bag_open")
util.AddNetworkString("hg_bag_sync")
util.AddNetworkString("hg_bag_take")



function hg_bag.CanInsert(ply, bag, wep)
if not IsValid(wep) then return false end
if hg_bag.Blacklist[wep:GetClass()] then return false end
if #bag.Inventory >= hg_bag.Slots then return false end
return true
end


function hg_bag.InsertWeapon(ply, bag)
local wep = ply:GetActiveWeapon()
if not hg_bag.CanInsert(ply, bag, wep) then return end


table.insert(bag.Inventory, wep:GetClass())
ply:StripWeapon(wep:GetClass())


hg_bag.Sync(bag)
end


function hg_bag.TakeWeapon(ply, bag, index)
local class = bag.Inventory[index]
if not class then return end


ply:Give(class)
table.remove(bag.Inventory, index)


hg_bag.Sync(bag)
end


function hg_bag.Sync(bag)
net.Start("hg_bag_sync")
net.WriteEntity(bag)
net.WriteTable(bag.Inventory)
net.Broadcast()
end


net.Receive("hg_bag_take", function(_, ply)
local bag = net.ReadEntity()
local index = net.ReadUInt(8)


if not IsValid(bag) or bag:GetClass() ~= "hg_bag" then return end
if (bag:GetPos() - ply:GetPos()):LengthSqr() > 150 * 150 then return end


hg_bag.TakeWeapon(ply, bag, index)
end)
--NONONNONOO FUCK ARMOR AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
--ну и залупа канешна
