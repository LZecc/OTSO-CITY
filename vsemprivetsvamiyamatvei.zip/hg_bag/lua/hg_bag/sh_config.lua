hg_bag = hg_bag or {}


-- количество слотов (как в инвентаре на скрине: 5x4)
hg_bag.Slots = 20


-- запрет на складывание
hg_bag.Blacklist = {
["weapon_hands_sh"] = true
}