ENT.Type = "anim"
ENT.Base = "base_gmodentity"


ENT.PrintName = "Сумка"
ENT.Category = "ZCity Other"
ENT.Spawnable = true
ENT.AdminSpawnable = true
ENT.Model = "models/eft_props/gear/backpacks/bp_forward.mdl" --fuck no model

ENT.IconOverride = "vgui/icons/dufflebag" --fuck no icon
--fuck 
function ENT:SetupDataTables()
self:NetworkVar("Int", 0, "ItemCount")
end


