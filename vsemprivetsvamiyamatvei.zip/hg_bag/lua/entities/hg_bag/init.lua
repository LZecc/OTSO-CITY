AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")
include("shared.lua")

ENT.IconOverride = "vgui/icons/dufflebag"

function ENT:Initialize()
    self:SetModel("models/eft_props/gear/backpacks/bp_forward.mdl")
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)

    local phys = self:GetPhysicsObject()
    if IsValid(phys) then phys:Wake() end

    -- ХУЕСОС512
    self.inventory = {
        Weapons = {},
        Ammo = {},
        Armor = {},
        Attachments = {}
    }

    self:SetNetVar("Inventory", self.inventory)
end

hook.Add("PlayerUse", "hg_bag_put_weapon", function(ply, ent)
    if not IsValid(ent) or ent:GetClass() ~= "hg_bag" then return end

    local wep = ply:GetActiveWeapon()
    if not IsValid(wep) then return false end
--ПОШЕЛ НАХУЙ
    if wep:GetClass() == "weapon_hands_sh" then return false end

    ent.inventory = ent.inventory or {
        Weapons = {},
        Ammo = {},
        Armor = {},
        Attachments = {}
    }

    ent.inventory.Weapons[wep:GetClass()] = wep

    ply:StripWeapon(wep:GetClass())

    ent:SetNetVar("Inventory", ent.inventory)

    return false
end)
