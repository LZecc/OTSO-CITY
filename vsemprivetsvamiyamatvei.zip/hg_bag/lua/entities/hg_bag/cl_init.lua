include("shared.lua")


net.Receive("hg_bag_open", function()
local bag = net.ReadEntity()
if not IsValid(bag) then return end


local fr = vgui.Create("DFrame")
fr:SetSize(400, 300)
fr:Center()
fr:SetTitle("Сумка")
fr:MakePopup()


local list = vgui.Create("DListView", fr)
list:Dock(FILL)
list:AddColumn("Items")


for _, class in ipairs(bag.Inventory or {}) do
list:AddLine(class)
end


list.OnRowSelected = function(_, _, row)
net.Start("hg_bag_take")
net.WriteEntity(bag)
net.WriteString(row:GetColumnText(1))
net.SendToServer()
fr:Close()
end


local put = vgui.Create("DButton", fr)
put:Dock(BOTTOM)
put:SetText("Put active weapon")
put.DoClick = function()
net.Start("hg_bag_put")
net.WriteEntity(bag)
net.SendToServer()
fr:Close()
end
end)