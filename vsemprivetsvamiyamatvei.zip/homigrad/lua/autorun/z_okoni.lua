if SERVER then
    util.AddNetworkString("Z_Laws_Update")

    local laws = {
        "Нелегал - тюрьма",
        "Убийства - тюрьма",
        "Оружие/Бизнес без лицензии - тюрьма",
        "Неподчинение госсам - тюрьма"
    }

    local function BroadcastLaws()
        net.Start("Z_Laws_Update")
        net.WriteTable(laws)
        net.Broadcast()
    end

    
    concommand.Add("Z_kons", function(ply, cmd, args)
        if not args[1] then
            print("Использование: Z_kons add \"текст\" | Z_kons remove <номер> | Z_kons clear | Z_kons list")
            return
        end

        local action = string.lower(args[1])

        if action == "add" then
            local text = table.concat(args, " ", 2)
            if text == "" then return end
            table.insert(laws, text)
            print("Добавлен закон: " .. text)
            BroadcastLaws()

        elseif action == "remove" then
            local idx = tonumber(args[2])
            if not idx or not laws[idx] then return end
            print("Удалён закон №" .. idx .. ": " .. laws[idx])
            table.remove(laws, idx)
            BroadcastLaws()

        elseif action == "clear" then
            laws = {}
            print("Vso ydaleno")
            BroadcastLaws()

        elseif action == "list" then
            print("\n=== Законы города ===")
            for k, v in ipairs(laws) do
                print(k .. ". " .. v)
            end
            print("====================\n")
        else
            print("УЕБАН ТУПОЙ НАПИШИ НОРМАЛЬНУЮ КОМАНДУ ЖЫРОБАС")
        end
    end)

    
    hook.Add("PlayerInitialSpawn", "Z_Laws_SendOnJoin", function(ply)
        net.Start("Z_Laws_Update")
        net.WriteTable(laws)
        net.Send(ply)
    end)

else -- CLIENT =====================

    local laws = {}
    local lawsPanel

   
    net.Receive("Z_Laws_Update", function()
        laws = net.ReadTable()
        if IsValid(lawsPanel) then
            lawsPanel:Remove()
            lawsPanel = nil
        end
        
        ShowLawsMenu()
    end)

    function ShowLawsMenu()
        if IsValid(lawsPanel) then lawsPanel:Remove() end

        lawsPanel = vgui.Create("DFrame")
        lawsPanel:SetSize(300, 300)
        lawsPanel:SetPos(ScrW() - 320, 20)
        lawsPanel:SetTitle("Законы города")
        lawsPanel:ShowCloseButton(false)
        lawsPanel:SetDraggable(false)
        lawsPanel:SetBackgroundBlur(false)
        lawsPanel:SetAlpha(0)
        lawsPanel:AlphaTo(255, 0.2, 0)

        
        lawsPanel.Paint = function(self, w, h)
            draw.RoundedBox(8, 0, 0, w, h, Color(0, 0, 0, 120))
        end

        local scroll = vgui.Create("DScrollPanel", lawsPanel)
        scroll:Dock(FILL)

        for k, v in ipairs(laws) do
            local lbl = scroll:Add("DLabel")
            lbl:SetText(k .. ". " .. v)
            lbl:SetFont("DermaDefaultBold")
            lbl:SetWrap(true)
            lbl:Dock(TOP)
            lbl:DockMargin(5, 5, 5, 0)
        end
    end

    function HideLawsMenu()
        if IsValid(lawsPanel) then
            lawsPanel:AlphaTo(0, 0.2, 0, function()
                if IsValid(lawsPanel) then lawsPanel:Remove() end
            end)
        end
    end

    
    local firstTime = true
    local firstTime4 = true

    hook.Add("Think", "Z_Laws_ShowOnKey", function()
        local isOpenKey = (engine.ActiveGamemode() ~= "sandbox" and input.IsKeyDown(KEY_Q))
            or (engine.ActiveGamemode() == "sandbox" and input.IsKeyDown(KEY_C))

        if isOpenKey then
            if firstTime then
                firstTime = false
                ShowLawsMenu()
            end
            firstTime4 = true
        else
            if firstTime4 then
                firstTime4 = false
                HideLawsMenu()
            end
            firstTime = true
        end
    end)
end
